﻿namespace net.openstack.Core.Exceptions.Response
{
    using System.Runtime.CompilerServices;

    /// <summary>
    /// The <see cref="net.openstack.Core.Exceptions.Response"/> namespace contains
    /// exception classes that represent errors returned by a call to a REST API.
    /// </summary>
    [CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}
