﻿using net.culqi.Client;
using net.culqi.Core;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace net.culqi.Providers
{
    public abstract class ProviderBase<TProvider> 
        where TProvider : class
    {
        /// <summary>
        /// The REST service implementation to use for requests sent from this provider.
        /// </summary>
        protected readonly IRestService restService;

        protected ProviderBase() 
            : this(null)
        {
        }

        protected ProviderBase(IRestService restService) 
        {
            this.restService = restService ?? new JsonRestServices();
        }

        protected async Task<Response<T>> ExecuteRESTRequestAsync<T>(Uri absoluteUri, HttpMethod method, object body = null, Dictionary<string, string> queryStringParameter = null, Dictionary<string, string> headers = null, bool isRetry = false, bool isTokenRequest = false, RequestSettings settings = null)
        {
            if (absoluteUri == null)
                throw new ArgumentNullException("absoluteUri");

            return await ExecuteRESTRequestAsync<Response<T>>(absoluteUri, method, body, queryStringParameter, headers, isRetry, isTokenRequest, settings, restService.ExecuteAsync<T>);
        }

        private async Task<T> ExecuteRESTRequestAsync<T>(Uri absoluteUri, HttpMethod method, object body, Dictionary<string, string> queryStringParameter, Dictionary<string, string> headers, bool isRetry, bool isTokenRequest, RequestSettings requestSettings,
            Func<Uri, HttpMethod, string, Dictionary<string, string>, Dictionary<string, string>, RequestSettings, Task<T>> callback) where T : Response
        {
            if (absoluteUri == null)
                throw new ArgumentNullException("absoluteUri");


            //if (requestSettings == null)
            //{
            //    requestSettings = BuildDefaultRequestSettings();
            //}                

            if (headers == null)
                headers = new Dictionary<string, string>();

            if (!isTokenRequest)
                headers["X-Auth-Token"] = "sss";

            string bodyStr = null;
            if (body != null)
            {
                if (body is JObject)
                    bodyStr = body.ToString();
                else if (body is string)
                    bodyStr = body as string;
                else
                    bodyStr = JsonConvert.SerializeObject(body, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            }

            //if (string.IsNullOrEmpty(requestSettings.UserAgent))
            //{
            //    requestSettings.UserAgent = DefaultUserAgent;
            //}
                

            var response = await callback(absoluteUri, method, bodyStr, headers, queryStringParameter, requestSettings);

            //// on errors try again 1 time.
            //if (response.StatusCode == HttpStatusCode.Unauthorized && !isRetry && !isTokenRequest)
            //{
            //    return await ExecuteRESTRequestAsync<T>(absoluteUri, method, body, queryStringParameter, headers, true, isTokenRequest, requestSettings, callback);
            //}

            CheckResponse(response);

            return response;
        }

        internal void CheckResponse(Response response)
        {
            if (response == null)
                throw new ArgumentNullException("response");

            new HttpResponseCodeValidator().Validate(response);
        }
    }
}
