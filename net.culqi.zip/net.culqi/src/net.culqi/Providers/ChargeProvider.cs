﻿using net.culqi.Core;
using net.culqi.Core.Domain;
using net.culqi.Core.Providers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace net.culqi.Providers
{
    public class ChargeProvider : ProviderBase<IChargeService>, IChargeService 
    {
        public ChargeProvider() :
            base()
        {
        }

        public async Task<object> CreateAsync(Core.Domain.Charge charge, CancellationToken cancellationToken)
        {
            var urlPath = new Uri("http://localhost/api/v2/charges");
            var requestBody = new Charge() { Amount = "955" };
            var response = await this.ExecuteRESTRequestAsync<ChargeReponse>(urlPath, HttpMethod.Post, requestBody);

            if (response == null || response.Data == null)
                return null;
            
            return "";
        }
    }
}
