﻿using net.culqi.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace net.culqi.Core.Providers
{
    public interface IChargeService
    {
        Task<object> CreateAsync(Charge charge, CancellationToken cancellationToken);        
    }
}
