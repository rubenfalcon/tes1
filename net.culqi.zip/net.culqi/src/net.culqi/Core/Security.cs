﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace net.culqi.Core
{
    public class Security
    {
        public Security()
        {
        }

        public string public_key { get; set; }

        public string private_key { get; set; }
    }
}
