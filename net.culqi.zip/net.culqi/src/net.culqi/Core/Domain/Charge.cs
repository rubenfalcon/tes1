﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace net.culqi.Core.Domain
{
    [JsonObject(MemberSerialization.OptIn)]
    public class Charge
    {
        [JsonProperty("object")]
        public string Object  { get; set; }

        [JsonProperty("capture")]
        public bool Capture  { get; set; }

        [JsonProperty("amount")]
        public string Amount { get; set; }

        [JsonProperty("currency_code ")]        
        public string  CurrencyCode { get; set; }

        [JsonProperty("email ")]        
        public string Email { get; set; }

        [JsonProperty("source_id  ")]        
        public string SourceId { get; set; }

        [JsonProperty("metadata")]
        private Dictionary<string, string> MetaData;
    }

    public class ChargeReponse
    {
 
    }
}
