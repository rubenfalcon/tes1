﻿using net.culqi.Core.Domain;
using net.culqi.Providers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace net.culqi.ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {

            var r = new ChargeProvider();

            var t = r.CreateAsync(new Charge(), CancellationToken.None).Result;
        }
    }
}
