﻿using Microsoft.Owin;
using Microsoft.Owin.Security.OAuth;
using Microsoft.Practices.Unity;
using Nancy.Owin;
using Nancy.TinyIoc;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1nancy
{    
    public class Startup
    {
        public static IUnityContainer container;

        public void Configuration(IAppBuilder app)
        {
            container = new UnityContainer();

            // Register Dependencies:
            RegisterDependencies(container);

            // Initialize Authentication:
            SetupAuth(app, container);

            // Initialize Nancy:
            SetupNancy(app, container);            
        }

        private void RegisterDependencies(IUnityContainer container)
        {
            // Make some Registrations:
            //container.Register<IMappingProvider, MappingProvider>();
            //container.Register<IConnectionStringProvider, ConnectionStringProvider>();
            //container.Register<IDatabaseFactory, DatabaseFactory>().AsSingleton();
            //container.Register<IApplicationSettings, ApplicationSettings>();
            //container.Register<ICryptoService, CryptoService>();
            //container.Register<IRegistrationService, RegistrationService>();
            //container.Register<IHashProvider, HashProvider>();
            //container.Register<IAuthenticationService, AuthenticationService>();
        }

        private void SetupAuth(IAppBuilder app, IUnityContainer container)
        {                                     
            //var settings = container.Resolve<IApplicationSettings>();

            // Use default options:
            app.UseOAuthBearerAuthentication(new OAuthBearerAuthenticationOptions()
            {
                //Provider = new OAuthTokenProvider(
                //    req => req.Query.Get("bearer_token"),
                //    req => req.Query.Get("access_token"),
                //    req => req.Query.Get("token"),
                //    req => req.Headers.Get("X-Token"))
            });

            // Register a Token-based Authentication for the App:            
            //app.UseOAuthAuthorizationServer(new OAuthAuthorizationServerOptions
            //{
            //    AllowInsecureHttp = true, // you should use this for debugging only
            //    TokenEndpointPath = new PathString(settings.TokenEndpointBasePath),
            //    AccessTokenExpireTimeSpan = TimeSpan.FromHours(8),
            //    Provider = new SimpleAuthorizationServerProvider(container.Resolve<IAuthenticationService>()),
            //});
        }

        private void SetupNancy(IAppBuilder app, IUnityContainer container)
        {
            //var settings = container.Resolve<IApplicationSettings>();            

            NancyOptions options = new NancyOptions()
            {
                Bootstrapper = new MyBootstrapper(container)
            };

            app.Map("/app", siteBuilder => 
            {
                siteBuilder.UseDemoMiddleware();
                siteBuilder.UseNancy(options);                
            });
        }
    }
}