﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebApplication1nancy
{
    public class ApiPacket
    {
        public string CallerIdentity { get; set; }
        public Guid TrackingId { get; set; }

        public string Verb { get; set; }

        public Uri RequestUri { get; set; }

        public Microsoft.Owin.IHeaderDictionary RequestHeaders { get; set; }

        public string Response { get; set; }

        public string Request { get; set; }

        public int StatusCode { get; set; }

        public string ReasonPhrase { get; set; }

        public Microsoft.Owin.IHeaderDictionary ResponseHeaders { get; set; }
    }
}
