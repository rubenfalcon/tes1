﻿using Microsoft.Owin;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace WebApplication1nancy
{
    public class PacketTrackingMiddleware2 : OwinMiddleware
    {
        public PacketTrackingMiddleware2(OwinMiddleware next)
            : base(next)
        {
            
        }

        public override async Task Invoke(IOwinContext context)
        {
            //IOwinContext context = context;
            var request = context.Request;
            var response = context.Response;

            //capture details about the caller identity

            var identity = (request.User != null && request.User.Identity.IsAuthenticated)
                ? request.User.Identity.Name
                : "(anonymous)";

            var apiPacket = new ApiPacket
            {
                CallerIdentity = identity
            };

            //buffer the request stream in order to intercept downstream reads
            //var requestBuffer = new MemoryStream();
            //request.Body = requestBuffer;            

            //buffer the response stream in order to intercept downstream writes
            var responseStream = response.Body;
            var responseBuffer = new MemoryStream();
            response.Body = responseBuffer;
            
            //add the "Http-Tracking-Id" response header
            //context.Response.OnSendingHeaders(state =>
            //{
            //    var ctx = state as IOwinContext;
            //    if (ctx == null) return;
            //    var resp = ctx.Response;

            //    //adding the tracking id response header so that the user
            //    //of the API can correlate the call back to this entry
            //    resp.Headers.Add("http-tracking-id", new[] { apiPacket.TrackingId.ToString("d") });
            //}, context);
            var responseHeaders = (IDictionary<string, string[]>)context.Environment["owin.ResponseHeaders"];
            responseHeaders["http-tracking-id"] = new[] { apiPacket.TrackingId.ToString("d") };

            //rewind the request and response buffers to record their content
            WriteRequestHeaders(request, apiPacket);
            //requestBuffer.Seek(0, SeekOrigin.Begin);
            //await request.Body.CopyToAsync(requestBuffer);
            var requestReader = new StreamReader(context.Request.Body);
            apiPacket.Request = await requestReader.ReadToEndAsync();
            request.Body.Position = 0;

            //invoke the next middleware in the pipeline
            await this.Next.Invoke(context);            
            

            WriteResponseHeaders(response, apiPacket);
            responseBuffer.Seek(0, SeekOrigin.Begin);
            //await response.Body.CopyToAsync(responseBuffer);
            var reader = new StreamReader(responseBuffer);
            apiPacket.Response = await reader.ReadToEndAsync();

            //write the apiPacket to the database
            //await database.InsterRecordAsync(apiPacket);
            System.Diagnostics.Debug.WriteLine("TrackingId: " + apiPacket.TrackingId);

            //make sure the response we buffered is flushed to the client
            responseBuffer.Seek(0, SeekOrigin.Begin);
            await responseBuffer.CopyToAsync(responseStream);
        }
        private static void WriteRequestHeaders(IOwinRequest request, ApiPacket packet)
        {
            packet.Verb = request.Method;
            packet.RequestUri = request.Uri;
            packet.RequestHeaders = request.Headers;
        }
        private static void WriteResponseHeaders(IOwinResponse response, ApiPacket packet)
        {
            packet.StatusCode = response.StatusCode;
            packet.ReasonPhrase = response.ReasonPhrase;
            packet.ResponseHeaders = response.Headers;
        }        
    }
}