﻿using Nancy;
using Nancy.Bootstrapper;
using Nancy.TinyIoc;
using Nancy.Conventions;
using Owin;
using Nancy.Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Claims;
using Nancy.Bootstrappers.Unity;
using Microsoft.Practices.Unity;

namespace WebApplication1nancy
{
    public class MyBootstrapper : UnityNancyBootstrapper
    {
        private Microsoft.Practices.Unity.IUnityContainer _container;

        public MyBootstrapper(Microsoft.Practices.Unity.IUnityContainer container)            
        {
            _container = container;
        }

        protected override Microsoft.Practices.Unity.IUnityContainer GetApplicationContainer()
        {
            //_container.AddNewExtension<EnumerableExtension>();
            return _container;
        }

        protected override void RequestStartup(IUnityContainer container, IPipelines pipelines, NancyContext context)
        {
            base.RequestStartup(container, pipelines, context);

            var owinEnvironment = context.GetOwinEnvironment();

            //var principal = owinEnvironment?["server.User"] as ClaimsPrincipal;

            //if (principal == null) return;

            //var userName = principal.Identity.Name;
            //var claims = principal.Claims.Where(
            //    o => o.Type == ClaimTypes.Role)
            //    .Select(o => o.Value);
            //context.CurrentUser = new ValidatedUser(userName, claims);
        }

        protected override void ConfigureConventions(NancyConventions nancyConventions)
        {
            base.ConfigureConventions(nancyConventions);

            nancyConventions.StaticContentsConventions
                .Add(StaticContentConventionBuilder.AddDirectory("App", @"App"));
            nancyConventions.StaticContentsConventions
                .Add(StaticContentConventionBuilder.AddDirectory("fonts", @"fonts"));
            nancyConventions.StaticContentsConventions
                .Add(StaticContentConventionBuilder.AddDirectory("Scripts", @"Scripts"));
        }
    }

}