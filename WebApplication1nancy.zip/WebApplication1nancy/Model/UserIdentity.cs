﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1nancy.Model
{
    /// <summary>
    /// Represents a UserIdentity with a Users Name and Claims.
    /// </summary>
    public class UserIdentity
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public IList<ClaimIdentity> Claims { get; set; }
    }

    /// <summary>
    /// Represents a Claim with a Type and a Value.
    /// </summary>
    public class ClaimIdentity
    {
        public int Id { get; set; }

        public string Type { get; set; }

        public string Value { get; set; }
    }
}