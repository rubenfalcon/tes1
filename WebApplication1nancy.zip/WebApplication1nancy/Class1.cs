﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1nancy
{
    public class SecureModule : Nancy.NancyModule
    {
        public SecureModule() : base()
        {

        }
    }
}