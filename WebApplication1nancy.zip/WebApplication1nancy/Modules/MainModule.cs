﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nancy;
using Nancy.ModelBinding;

namespace WebApplication1nancy.Modules
{
    public class MainModule : SecureModule
    {
        public MainModule()
        {
            Post["/admin"] = _ =>
            {
                var e = this.Bind<test>();

                //if (!this.Principal.HasClaim(SampleClaimTypes.Admin))
                //{
                //    return HttpStatusCode.Forbidden;
                //}

                return "Hello Admin!";
            };

            Get["/"] = _ =>
            {
                //if (!IsAuthenticated)
                //{
                //    return HttpStatusCode.Forbidden;
                //}

                return "Hello User!";
            };
        }
    }

    public class test
    {
        public string Id { get; set; }
    }
}